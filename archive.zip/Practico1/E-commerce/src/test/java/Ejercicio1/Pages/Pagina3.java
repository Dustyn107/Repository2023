package Ejercicio1.Pages;

public class Pagina3 {

    public Pagina3() {
        System.out.println("Hola!! Soy la pagina2");
    }
    public void mostrarTitulo(){
        System.out.println("Soy el titulo 3 y estoy en online");
    }

}
