package PageObjects;

import org.openqa.selenium.WebDriver;

import java.sql.Driver;

public class LeaveOrangeHRMPage {

    private WebDriver driver;

    public LeaveOrangeHRMPage(WebDriver aDriver){

       driver = aDriver;
    }

    public void ValidarCalendario(){

       // driver.findElement()

    }
}
